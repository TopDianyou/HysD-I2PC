import torch
import torch.nn as nn
import torch.nn.functional as F
import os
import sys

sys.path.append(os.getcwd())

from models.pointTransformer.point_transformer import PointsEncoder_pointwise
from models.network_img.resnet import Image_ResNet

from utils.options import Options
from utils.loss import pose_loss
import numpy as np
import cv2

from models.LSTM.LSTM import SeismicTimeSeriesNetLite


os.environ['CUDA_LAUNCH_BLOCKING'] = '1'


class IPTMMatchNet(nn.Module):
    def __init__(self, opt: Options, is_pc_norm=True):
        super(IPTMMatchNet, self).__init__()
        self.opt = opt
        self.point_transformer = PointsEncoder_pointwise(is_pc_norm)

        self.resnet = Image_ResNet()
        self.LSTMModel = SeismicTimeSeriesNetLite(input_channels=576, lstm_hidden=64)

        print('# point net initialized')
        print('# pixel net initialized')
        print('# LSTM net initialized')

        self.pc_score_head = nn.Sequential(
            nn.Conv1d(640, 128, 1, bias=False),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.Conv1d(128, 64, 1, bias=False),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.Conv1d(64, 1, 1, bias=False),
            nn.Sigmoid())

        self.img_score_head = nn.Sequential(
            nn.Conv2d(64 + 512, 128, 1, bias=False),
            nn.BatchNorm2d(128),
            nn.ReLU(),
            nn.Conv2d(128, 64, 1, bias=False),
            nn.BatchNorm2d(64), nn.ReLU(),
            nn.Conv2d(64, 1, 1, bias=False),
            nn.Sigmoid())

        self.img_feature_layer = nn.Sequential(nn.Conv2d(64, 64, 1, bias=False), nn.BatchNorm2d(64), nn.ReLU(),
                                               nn.Conv2d(64, 64, 1, bias=False), nn.BatchNorm2d(64), nn.ReLU(),
                                               nn.Conv2d(64, 64, 1, bias=False))
        self.pc_feature_layer = nn.Sequential(nn.Conv1d(128, 64, 1, bias=False), nn.BatchNorm1d(64), nn.ReLU(),
                                              nn.Conv1d(64, 64, 1, bias=False), nn.BatchNorm1d(64), nn.ReLU(),
                                              nn.Conv1d(64, 64, 1, bias=False))
        self.downsample = nn.AvgPool2d(kernel_size=2, stride=2)

    #        self.LSTMModel = LSTMModel()

    def forward(self,pc,intensity,sn,img,times):
        pc_mean = pc.mean(dim=2, keepdim=True)  # 计算各坐标轴均值
        pc_centered = pc - pc_mean  # 中心化处理
        pc_dist = torch.sqrt(torch.sum(pc_centered ** 2, dim=1, keepdim=True))  # 计算各点距中心距离
        max_dist = torch.max(pc_dist, dim=2, keepdim=True)[0]  # 获取最大距离
        pc_normalized = pc_centered / (max_dist + 1e-8)  # 缩放至单位球

        # 强度标准化（逐样本Z-Score）
        intensity_mean = intensity.mean(dim=2, keepdim=True)
        intensity_std = intensity.std(dim=2, keepdim=True)
        intensity_normalized = (intensity - intensity_mean) / (intensity_std + 1e-8)

        # 法线向量归一化（L2单位化）
        sn_normalized = F.normalize(sn, p=2, dim=1)  # 保持法线方向不变，模长变为1

        input = torch.cat((pc_normalized, intensity_normalized, sn_normalized), dim=1)

        global_img_feat, pixel_wised_feat, img_upsample_s2 = self.resnet(img)
        global_pc_feat, point_wised_feat = self.point_transformer(input)

        batch_inds = torch.arange(pc.shape[0]).reshape(-1, 1).repeat(1, pc.shape[2]).reshape(-1, 1).cuda()
        corrds = pc.transpose(2, 1) - torch.min(pc.transpose(2, 1), dim=1, keepdim=True)[0]
        corrds = corrds.reshape(-1, 3)
        corrds = torch.round(corrds / 0.05)
        corrds = torch.cat((corrds, batch_inds), dim=-1)

        point_wised_feat = point_wised_feat

        img_feat_fusion = torch.cat((pixel_wised_feat,
                                     global_pc_feat.unsqueeze(-1).unsqueeze(-1).repeat(1, 1, pixel_wised_feat.shape[2],
                                                                                       pixel_wised_feat.shape[3])),
                                    dim=1)

        pc_feat_fusion = torch.cat(
            (point_wised_feat, global_img_feat.unsqueeze(-1).repeat(1, 1, point_wised_feat.shape[2])), dim=1)

        img_score = self.img_score_head(img_feat_fusion)
        pc_score = self.pc_score_head(pc_feat_fusion)

        pixel_wised_feat = self.img_feature_layer(pixel_wised_feat)
        point_wised_feat = self.pc_feature_layer(point_wised_feat)
        point_wised_feat = F.normalize(point_wised_feat, dim=1, p=2)
        pixel_wised_feat = F.normalize(pixel_wised_feat, dim=1, p=2)

        #LSTM_feat =torch.cat((self.downsample(LSTM_feat1), img_feat_fusion), dim=1)
        LSTM_feat = torch.cat((img_upsample_s2,
                                     global_pc_feat.unsqueeze(-1).unsqueeze(-1).repeat(1, 1, img_upsample_s2.shape[2],
                                                                                       img_upsample_s2.shape[3])),
                                    dim=1)

        LSTM_damage = self.LSTMModel(LSTM_feat.unsqueeze(0), times.unsqueeze(0))

        return pixel_wised_feat, point_wised_feat, img_score, pc_score, LSTM_damage






