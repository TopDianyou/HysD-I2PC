import torch
import torch.nn as nn
import torch.nn.functional as F


class SeismicTimeSeriesNetLite(nn.Module):
    def __init__(self, input_channels=64, time_steps=21, lstm_hidden=64):
        super().__init__()
        self.time_steps = time_steps

        # 优化后的空间特征提取模块
        self.spatial_encoder = nn.Sequential(
            # 快速下采样阶段
            nn.Conv2d(input_channels, 64, 5, stride=2, padding=2),  # H,W减半
            nn.InstanceNorm2d(64),
            nn.GELU(),
            nn.MaxPool2d(2),  # 再次减半

            # 深度可分离卷积
            nn.Conv2d(64, 64, 3, padding=1, groups=64),
            nn.Conv2d(64, 128, 1),  # 通道混合
            nn.InstanceNorm2d(128),
            nn.GELU(),
            nn.MaxPool2d(2),  # 继续下采样

            # 最终特征压缩
            nn.AdaptiveAvgPool2d((4, 4)),
            nn.Flatten(),
            nn.Linear(128 * 4 * 4, 256),  # 显著减少线性层参数
            nn.LayerNorm(256)
        )

        # 紧凑时间编码
        self.time_embed = nn.Sequential(
            nn.Linear(1, 32),
            nn.GELU(),
            nn.Linear(32, 32)
        )

        # 轻量级时序建模
        self.temporal_model = nn.LSTM(
            input_size=256 + 32,  # 调整后的输入维度
            hidden_size=lstm_hidden,
            num_layers=1,  # 减少层数
            bidirectional=False,
            dropout=0.2,
            batch_first=True
        )


        # 精简预测头
        self.timewise_predictor = nn.Sequential(
            nn.Linear(2 * lstm_hidden, 32),
            nn.GELU(),
            nn.Dropout(0.2),
            nn.Linear(32, 1)
        )

        # 参数初始化
        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.kaiming_normal_(m.weight)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)

    def forward(self, x, times):
        B, T = x.size(0), x.size(1)

        # 空间特征提取
        spatial_feat = self.spatial_encoder(
            x.view(B * T, *x.shape[2:])
        )

        # 时间编码
        time_feat = self.time_embed(times.view(-1, 1).float())

        # 特征融合
        combined = torch.cat([spatial_feat, time_feat], dim=1)
        combined = combined.view(B, T, -1)

        # 时序建模
        lstm_out, _ = self.temporal_model(combined)

        # 注意力增强（直接使用batch_first）
        #attn_out, _ = self.temporal_attention(lstm_out, lstm_out, lstm_out)

        # 残差融合
        fused_feat = lstm_out

        # 最终预测
        return self.timewise_predictor(fused_feat).squeeze(0)


# 测试轻量版网络
if __name__ == "__main__":
    B, T, C, H, W = 1, 21, 64, 384, 512
    model = SeismicTimeSeriesNetLite(input_channels=C)

    dummy_x = torch.randn(T, C, H, W)
    dummy_t = torch.rand(T) * 10

    print("输入时间序列:", dummy_t)
    output = model(dummy_x.unsqueeze(0), dummy_t.unsqueeze(0))

    print(f"输出尺寸: {output.shape}")
    print(f"参数量: {sum(p.numel() for p in model.parameters()) / 1e6:.2f}M")