import os
import numpy as np
import torch
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
from sklearn.manifold import TSNE
import psutil


class TimeAwareTSNEVisualizer:
    def __init__(
            self,
            save_dir: str = "./outs/tsne_results",
            img_feat_shape: tuple = (196, 256),  # 输入图像特征尺寸 (H, W)
            samples_per_sample: int = 2000,  # 每个样本采样点数
            max_total_samples: int = 40000,  # 最大处理样本数
            cmap_name: str = "viridis",  # 颜色映射方案
            seed: int = 42,
            n_jobs: int = 4
    ):
        """
        支持动态时间范围和分模态可视化的改进版TSNE分析器

        Args:
            img_feat_shape: 图像特征图尺寸 (height, width)
            samples_per_sample: 每个样本(图像/点云)的采样点数
            max_total_samples: 最大处理样本数（防止内存溢出）
            cmap_name: matplotlib支持的颜色映射名称
        """
        try:
            physical_cores = psutil.cpu_count(logical=False) or os.cpu_count()
            os.environ["LOKY_MAX_CPU_COUNT"] = str(physical_cores)
        except:
            os.environ["LOKY_MAX_CPU_COUNT"] = str(os.cpu_count())
        # 参数校验
        assert samples_per_sample > 0, "采样数必须大于零"
        assert max_total_samples > 1000, "最大样本数过小"

        # 初始化参数
        self.save_dir = save_dir
        self.img_h, self.img_w = img_feat_shape
        self.samples_per_sample = samples_per_sample
        self.max_total_samples = max_total_samples
        self.cmap = plt.get_cmap(cmap_name)
        self.seed = seed
        self.n_jobs = n_jobs

        # 数据缓存
        self.feature_buffer = []  # 存储特征向量
        self.modality_buffer = []  # 存储模态标签 (0:图像, 1:点云)
        self.time_buffer = []  # 存储时间戳

        # 创建保存目录
        os.makedirs(save_dir, exist_ok=True)

        # 固定随机种子
        np.random.seed(seed)
        torch.manual_seed(seed)

    def _sample_image_features(self, img_feat: torch.Tensor) -> np.ndarray:
        """修正版图像采样：精确采样指定点数"""
        B, C, H, W = img_feat.shape
        # 生成所有可能的坐标对
        all_coords = torch.stack(torch.meshgrid(
            torch.arange(H),
            torch.arange(W),
            indexing='ij'
        ), dim=-1).reshape(-1, 2)  # (H*W, 2)

        # 随机选择不重复的点
        idx = torch.randperm(len(all_coords))[:self.samples_per_sample]
        selected_coords = all_coords[idx]

        # 提取特征 (B, C, S) -> (B*S, C)
        sampled = img_feat[:, :, selected_coords[:, 0], selected_coords[:, 1]]
        return sampled.permute(0, 2, 1).reshape(-1, C).cpu().numpy()

    def _sample_pointcloud_features(self, pc_feat: torch.Tensor) -> np.ndarray:
        """点云采样（保持原实现）"""
        B, C, N = pc_feat.shape
        idx = torch.randint(0, N, (B, self.samples_per_sample))
        sampled = torch.gather(pc_feat, 2, idx.unsqueeze(1).expand(-1, C, -1))
        return sampled.permute(0, 2, 1).reshape(-1, C).cpu().numpy()

    def add_batch(
            self,
            img_feat: torch.Tensor,  # (B, 64, H, W)
            pc_feat: torch.Tensor,  # (B, 64, N)
            timestamps: list  # 每个样本的绝对时间 [t1, t2,...tB]
    ):
        """
        添加批次数据到缓存

        Args:
            img_feat: 图像特征张量
            pc_feat: 点云特征张量
            timestamps: 对应每个样本的时间值列表（长度=B）
        """

        batch_size = img_feat.shape[0]
        assert len(timestamps) == batch_size, "时间戳数量与批次大小不匹配"

        # 图像特征采样并添加
        img_samples = self._sample_image_features(img_feat)
        self.feature_buffer.append(img_samples)
        self.modality_buffer.extend([0] * len(img_samples))
        self.time_buffer.extend(np.repeat(timestamps, self.samples_per_sample))

        # 点云特征采样并添加
        pc_samples = self._sample_pointcloud_features(pc_feat)
        self.feature_buffer.append(pc_samples)
        self.modality_buffer.extend([1] * len(pc_samples))
        self.time_buffer.extend(np.repeat(timestamps, self.samples_per_sample))

    def _downsample(self, features: np.ndarray, labels: np.ndarray, times: np.ndarray):
        """均衡下采样以防止内存溢出"""
        # 计算需要保留的样本比例
        keep_ratio = self.max_total_samples / len(features)
        if keep_ratio >= 1:
            return features, labels, times

        # 分层采样保持模态比例
        img_mask = (labels == 0)
        pc_mask = (labels == 1)

        # 图像特征下采样索引
        img_idx = np.random.choice(
            np.where(img_mask)[0],
            size=int(np.sum(img_mask) * keep_ratio),
            replace=False
        )

        # 点云特征下采样索引
        pc_idx = np.random.choice(
            np.where(pc_mask)[0],
            size=int(np.sum(pc_mask) * keep_ratio),
            replace=False
        )

        # 合并索引
        selected = np.concatenate([img_idx, pc_idx])
        return features[selected], labels[selected], times[selected]

    def visualize(self, epoch: int, prefix: str = ""):
        """执行可视化"""
        # 合并数据
        features = np.concatenate(self.feature_buffer)
        modalities = np.array(self.modality_buffer)
        times = np.array(self.time_buffer)

        # 下采样
        features, modalities, times = self._downsample(features, modalities, times)

        # 动态计算时间范围
        t_min, t_max = np.min(times), np.max(times)


        # 执行t-SNE
        tsne = TSNE(
            n_components=2,
            perplexity=30,
            learning_rate=200,
            metric='cosine',
            init='pca',
            n_jobs=self.n_jobs,
            random_state=self.seed
        )
        embeddings = tsne.fit_transform(features)
        norm = Normalize(vmin=t_min, vmax=t_max)
        # 创建三维画布
        fig = plt.figure(figsize=(15, 12))
        ax = fig.add_subplot(111, projection='3d')

        # 时间标准化（可选）
        norm_time = Normalize(vmin=t_min, vmax=t_max)
        times_norm = norm_time(times)  # 映射到[0,1]方便颜色映射

        # 绘制图像特征（圆形）
        img_mask = (modalities == 0)
        sc_img = ax.scatter(
            embeddings[img_mask, 0],  # x轴：t-SNE 1
            embeddings[img_mask, 1],  # y轴：t-SNE 2
            zs=times[img_mask],  # z轴：时间戳
            zdir='z',  # 指定z轴方向
            c=self.cmap(times_norm[img_mask]),  # 颜色仍映射时间
            marker='o',
            s=10,
            alpha=0.6,
            label='Image Features'
        )

        # 绘制LiDAR特征（方形）
        pc_mask = (modalities == 1)
        sc_pc = ax.scatter(
            embeddings[pc_mask, 0],
            embeddings[pc_mask, 1],
            times[pc_mask],  # z值
            c=self.cmap(times_norm[pc_mask]),
            marker='s',
            s=10,
            alpha=0.6,
            label='LiDAR Features'
        )

        # 坐标轴标签
        ax.set_xlabel('t-SNE 1')
        ax.set_ylabel('t-SNE 2')
        ax.set_zlabel('Timestamp')
        ax.set_title(f"3D Temporal Feature View (Epoch {epoch})")

        # 颜色条（共享时间映射）
        cax = fig.add_axes([0.92, 0.2, 0.02, 0.6])  # 调整位置
        sm = plt.cm.ScalarMappable(norm=norm_time, cmap=self.cmap)
        fig.colorbar(sm, cax=cax, label='Normalized Time')

        # 视角调整（俯仰角30°, 方位角-45°）
        ax.view_init(elev=30, azim=-45)

        # 保存与清理
        filename = f"{prefix}3d_time_tsne_epoch{epoch}-{t_min:.2f}-{t_max:.2f}.png"
        plt.savefig(
            os.path.join(self.save_dir, filename),
            dpi=300,
            bbox_inches='tight'
        )
        plt.close()

        # 组织数据矩阵：x | y | time | modality
        save_data = np.column_stack([
            embeddings[:, 0],  # x
            embeddings[:, 1],  # y
            times,  # z (time)
            modalities  # 0/1
        ])

        # 定义列头注释
        header_txt = "Columns: t-SNE-X | t-SNE-Y | Timestamp | Modality(0=Image,1=LiDAR)"

        # 保存为TXT
        np.savetxt(
            os.path.join(self.save_dir, f"{prefix}tsne_time_epoch{epoch}-{t_min:.2f}-{t_max:.2f}.txt"),
            save_data,
            fmt='%.6f %.6f %.4f %d',  # 格式化精度
            header=header_txt
        )
        # 清空缓存（保持不变）
        self.feature_buffer.clear()
        self.modality_buffer.clear()
        self.time_buffer.clear()