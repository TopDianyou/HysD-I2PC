from TimeAwareTSNEVisualizer import TimeAwareTSNEVisualizer
import torch
# 初始化可视化器（假设时间范围在0~1秒之间）
visualizer = TimeAwareTSNEVisualizer(
    save_dir="./time_tsne",
    img_feat_shape=(192, 256),
    samples_per_sample=2000,  # 每个样本采300点
    max_total_samples=50000,
    cmap_name="plasma"
)

img_feat = torch.rand(21,64,192,256)
pc_feat  = torch.rand(21,64,40960)
timestamps = [0.1800, 0.7561, 0.2016, 0.9692, 0.2967, 0.4918, 0.5138, 0.9815, 0.9465,
        0.6976, 0.1889, 0.0104, 0.5489, 0.4806, 0.8563, 0.8302, 0.9387, 0.8257,
        0.9192, 0.4441, 0.0698]
print(timestamps)
epoch = 5
batch_idx = 21

current_time = batch_idx * 0.1

    # 收集带时间信息的特征
times_cpu = timestamps
img_features_all_cpu = img_feat.cpu()
pc_features_all_cpu = img_feat.cpu()
visualizer.add_batch(img_features_all_cpu, pc_features_all_cpu, times_cpu)
visualizer.visualize(epoch, prefix="exp1")
