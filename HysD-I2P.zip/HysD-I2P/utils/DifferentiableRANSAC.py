import torch
import torch.nn as nn
import torch.nn.functional as F


class DifferentiableRANSAC(nn.Module):
    def __init__(self, num_iter=50, num_hypotheses=8, inlier_thresh=0.01):
        super().__init__()
        self.num_iter = num_iter
        self.num_hypotheses = num_hypotheses
        self.inlier_thresh = inlier_thresh

    def forward(self, points_2d, points_3d, K, confidence):
        """
        Args:
            points_2d: (B, N, 2) 图像特征点
            points_3d: (B, N, 3) 3D点云
            K: (B, 3, 3) 内参矩阵
            confidence: (B, N) 点对应置信度

        Returns:
            best_extrinsic: (B, 4, 4) 预测外参矩阵
            inlier_mask: (B, N) 内点掩码
        """
        B, N, _ = points_2d.shape
        device = points_2d.device

        # 初始化最佳位姿
        best_extrinsic = torch.eye(4, device=device).repeat(B, 1, 1)
        best_score = torch.zeros(B, device=device)

        # 概率采样准备
        prob = F.softmax(confidence, dim=1)  # (B, N)

        for _ in range(self.num_iter):
            # 生成多个假设
            indices = self._differentiable_sample(prob, self.num_hypotheses)  # (B, H, 6)

            # 并行计算所有假设
            batch_indices = torch.arange(B, device=device)[:, None, None]
            sampled_2d = points_2d[batch_indices, indices]  # (B, H, 6, 2)
            sampled_3d = points_3d[batch_indices, indices]  # (B, H, 6, 3)

            # 计算假设位姿 (B*H, 4, 4)
            Hs = self._compute_hypotheses(
                sampled_2d.view(B * self.num_hypotheses, 6, 2),
                sampled_3d.view(B * self.num_hypotheses, 6, 3),
                K.repeat_interleave(self.num_hypotheses, dim=0)
            ).view(B, self.num_hypotheses, 4, 4)

            # 评估假设
            scores, inlier_masks = self._evaluate_hypotheses(
                Hs, points_2d, points_3d, K)

            # 更新最佳假设
            max_scores, max_indices = scores.max(dim=1)
            update_mask = max_scores > best_score
            if update_mask.any():
                best_extrinsic[update_mask] = Hs[update_mask, max_indices[update_mask]]
                best_score[update_mask] = max_scores[update_mask]

        # 最终优化使用所有内点（移除了 torch.no_grad()，使得整个过程可微）
        final_extrinsic, inlier_mask = self._refine_pose(
            best_extrinsic, points_2d, points_3d, K)

        return final_extrinsic, inlier_mask

    def _differentiable_sample(self, prob, num_samples):
        """可微分概率采样"""
        B, N = prob.shape
        device = prob.device

        # 使用Gumbel Softmax采样
        gumbel_noise = -torch.log(-torch.log(torch.rand(B, N, num_samples, device=device)))
        scores = (prob.unsqueeze(-1) + gumbel_noise)
        indices = torch.topk(scores, 6, dim=1).indices  # (B, 6, H)
        return indices.permute(0, 2, 1)  # (B, H, 6)

    def _compute_hypotheses(self, points_2d, points_3d, K):
        """Core PnP computation"""
        B_total = points_2d.shape[0]  # B_total = B * self.num_hypotheses
        device = points_2d.device

        fx = K[:, 0, 0].view(-1, 1, 1)
        fy = K[:, 1, 1].view(-1, 1, 1)
        cx = K[:, 0, 2].view(-1, 1, 1)
        cy = K[:, 1, 2].view(-1, 1, 1)

        # Expand shapes to match points_2d
        fx = fx.expand(B_total, -1, -1)
        fy = fy.expand(B_total, -1, -1)
        cx = cx.expand(B_total, -1, -1)
        cy = cy.expand(B_total, -1, -1)

        xn = (points_2d[..., 0] - cx.squeeze(-1)) / fx.squeeze(-1)  # (B_total, 6)
        yn = (points_2d[..., 1] - cy.squeeze(-1)) / fy.squeeze(-1)  # (B_total, 6)

        # Build the linear system
        X = points_3d[..., 0]  # (B_total, 6)
        Y = points_3d[..., 1]
        Z = points_3d[..., 2]

        # Construct the corrected matrix for each hypothesis
        row1 = torch.stack([
            X, Y, Z, torch.ones_like(X),
            torch.zeros_like(X), torch.zeros_like(X),
            torch.zeros_like(X), torch.zeros_like(X),
            -xn * X, -xn * Y, -xn * Z, -xn
        ], dim=-1)  # (B_total, 6, 12)

        row2 = torch.stack([
            torch.zeros_like(X), torch.zeros_like(X),
            torch.zeros_like(X), torch.zeros_like(X),
            X, Y, Z, torch.ones_like(X),
            -yn * X, -yn * Y, -yn * Z, -yn
        ], dim=-1)  # (B_total, 6, 12)

        A = torch.cat([row1, row2], dim=1)  # (B_total, 12, 12)

        # 对每个 hypothesis 单独进行 SVD 求解
        _, _, Vh = torch.linalg.svd(A)  # Vh shape: (B_total, 12, 12)
        params = Vh[:, -1, :]  # (B_total, 12)

        # 还原回原始 batch 维度：B = B_total // self.num_hypotheses
        B_orig = B_total // self.num_hypotheses
        params = params.view(B_orig, self.num_hypotheses, 12)  # (B, H, 12)

        R = params[:, :, :9].view(-1, 3, 3)  # (B * H, 3, 3)
        t = params[:, :, 9:].view(-1, 3)  # (B * H, 3)

        # 正交化处理：保证 R 为正交矩阵
        U, S, Vh = torch.linalg.svd(R)
        R_ortho = U @ Vh.transpose(-2, -1)
        det = torch.det(R_ortho).view(-1, 1, 1)
        R_ortho = R_ortho * torch.sign(det)

        # 构建外参矩阵
        extrinsic = torch.eye(4, device=device).repeat(B_total, 1, 1)
        extrinsic[:, :3, :3] = R_ortho
        extrinsic[:, :3, 3] = t

        return extrinsic

    def _evaluate_hypotheses(self, Hs, points_2d, points_3d, K):
        """假设评估"""
        B, H = Hs.shape[:2]
        device = Hs.device

        # 投影计算
        R = Hs[:, :, :3, :3]  # (B, H, 3, 3)
        t = Hs[:, :, :3, 3]  # (B, H, 3)

        # 转换到相机坐标系
        points_cam = torch.einsum('bhij,bnj->bhni', R, points_3d) + t.unsqueeze(2)  # (B, H, N, 3)

        # 投影到图像平面
        proj = torch.einsum('bij,bhnj->bhni', K, points_cam)  # (B, H, N, 3)
        proj_2d = proj[..., :2] / proj[..., 2:].clamp(min=1e-6)  # (B, H, N, 2)

        # 计算重投影误差
        error = torch.norm(proj_2d - points_2d.unsqueeze(1), dim=-1)  # (B, H, N)
        inlier_score = torch.sigmoid((self.inlier_thresh - error) * 100)

        # 计算假设得分
        scores = inlier_score.mean(dim=-1)  # (B, H)

        return scores, inlier_score

    def _refine_pose(self, init_pose, points_2d, points_3d, K):
        """使用加权最小二乘优化"""
        B, N, _ = points_2d.shape
        device = points_2d.device

        # 计算初始内点（移除 torch.no_grad() 以保持可微分）
        R = init_pose[:, :3, :3]
        t = init_pose[:, :3, 3]
        points_cam = torch.bmm(R, points_3d.transpose(1, 2)) + t.unsqueeze(-1)
        proj = torch.bmm(K, points_cam)
        proj_2d = proj[:, :2] / proj[:, 2:].clamp(min=1e-6)
        error = torch.norm(proj_2d.transpose(1, 2) - points_2d, dim=-1)
        inlier_weight = torch.exp(-error ** 2 / (2 * self.inlier_thresh ** 2))

        # 加权PnP
        fx = K[:, 0, 0].view(B, 1, 1)
        fy = K[:, 1, 1].view(B, 1, 1)
        cx = K[:, 0, 2].view(B, 1, 1)
        cy = K[:, 1, 2].view(B, 1, 1)

        # 调整内参张量形状，使之与 points_2d 匹配
        xn = (points_2d[..., 0] - cx.view(B, 1)) / fx.view(B, 1)
        yn = (points_2d[..., 1] - cy.view(B, 1)) / fy.view(B, 1)

        X = points_3d[..., 0]
        Y = points_3d[..., 1]
        Z = points_3d[..., 2]

        # 构建加权矩阵
        W = inlier_weight.view(B, N, 1)

        A1 = W * torch.stack([X, Y, Z, torch.ones_like(X),
                               torch.zeros_like(X), torch.zeros_like(X),
                               torch.zeros_like(X), torch.zeros_like(X),
                               -xn * X, -xn * Y, -xn * Z, -xn], dim=-1)

        A2 = W * torch.stack([torch.zeros_like(X), torch.zeros_like(X),
                               torch.zeros_like(X), torch.zeros_like(X),
                               X, Y, Z, torch.ones_like(X),
                               -yn * X, -yn * Y, -yn * Z, -yn], dim=-1)

        A = torch.cat([A1, A2], dim=1).view(B, 2 * N, 12)

        # SVD求解
        _, _, Vh = torch.linalg.svd(A)
        params = Vh[..., -1]

        R = params[:, :9].view(B, 3, 3)
        t = params[:, 9:].view(B, 3)

        # 正交化处理
        U, S, Vh = torch.linalg.svd(R)
        R_ortho = U @ Vh.transpose(-2, -1)
        det = torch.det(R_ortho).view(B, 1, 1)
        R_ortho = R_ortho * torch.sign(det)

        final_pose = torch.eye(4, device=device).repeat(B, 1, 1)
        final_pose[:, :3, :3] = R_ortho
        final_pose[:, :3, 3] = t

        return final_pose, inlier_weight > 0.5


class RANSACPoseLoss(nn.Module):
    def __init__(self, rot_weight=1.0, trans_weight=1.0*0.01, entropy_weight=0.1):
        super().__init__()
        self.rot_weight = rot_weight
        self.trans_weight = trans_weight
        self.entropy_weight = entropy_weight

    def forward(self, pred_pose, target_pose, confidence):
        # 位姿损失
        R_pred = pred_pose[:, :3, :3]
        t_pred = pred_pose[:, :3, 3]
        R_gt = target_pose[:, :3, :3]
        t_gt = target_pose[:, :3, 3]

        # 旋转损失
        R_diff = torch.bmm(R_pred, R_gt.transpose(1, 2))
        trace = torch.einsum('bii->b', R_diff)
        theta = torch.acos(torch.clamp((trace - 1) / 2, -1 + 1e-6, 1 - 1e-6))
        rot_loss = theta.mean()

        # 平移损失
        trans_loss = torch.norm(t_pred - t_gt, dim=1).mean()

        # 置信度熵正则化
        p = torch.sigmoid(confidence)
        entropy = -p * torch.log(p + 1e-6) - (1 - p) * torch.log(1 - p + 1e-6)
        entropy_loss = entropy.mean()

        total_loss = (self.rot_weight * rot_loss +
                      self.trans_weight * trans_loss +
                      self.entropy_weight * entropy_loss)

        return total_loss


# 测试代码
if __name__ == "__main__":
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    B, N = 2, 512

    # 生成模拟数据
    torch.manual_seed(42)

    # 真实外参
    gt_extrinsic = torch.eye(4).repeat(B, 1, 1).to(device)
    gt_R = torch.linalg.qr(torch.randn(B, 3, 3).to(device))[0]
    gt_t = torch.randn(B, 3).to(device) * 0.5
    gt_extrinsic[:, :3, :3] = gt_R
    gt_extrinsic[:, :3, 3] = gt_t

    # 内参矩阵
    K = torch.eye(3).repeat(B, 1, 1).to(device)
    K[:, 0, 0] = 800.0
    K[:, 1, 1] = 800.0
    K[:, 0, 2] = 320.0
    K[:, 1, 2] = 240.0

    # 生成3D点云并投影（添加离群点）
    points_3d = torch.randn(B, N, 3).to(device)
    points_cam = torch.bmm(gt_R, points_3d.transpose(1, 2)) + gt_t.unsqueeze(-1)
    points_2d = torch.bmm(K, points_cam)
    points_2d = points_2d[:, :2] / points_2d[:, 2:].clamp(min=1e-6)
    points_2d = points_2d.transpose(1, 2)

    # 添加噪声和离群点
    noise = torch.randn_like(points_2d) * 0.01
    outlier_mask = torch.rand(B, N, device=device) < 0.3  # 30%离群点
    noise[outlier_mask] += torch.randn_like(noise[outlier_mask]) * 0.5
    points_2d += noise

    # 生成置信度（模拟网络输出），并设置 requires_grad=True
    confidence = torch.randn(B, N, device=device, requires_grad=True)

    # 初始化模块
    ransac = DifferentiableRANSAC(num_iter=5, num_hypotheses=8).to(device)
    loss_fn = RANSACPoseLoss().to(device)

    # 前向计算
    pred_pose, inlier_mask = ransac(points_2d, points_3d, K, confidence)
    loss = loss_fn(pred_pose, gt_extrinsic, confidence)

    # 反向传播
    loss.backward()


    print("预测位姿示例：")
    print(pred_pose[0])
    print("\n真实位姿示例：")
    print(gt_extrinsic[0])
    print("\n内点比例：", inlier_mask.float().mean().item())
    print("总损失：", loss.item())
