from numpy import positive
import torch
import torch.nn.functional as F
import numpy as np

from scipy.spatial.transform import Rotation


def desc_loss_2(img_features, pc_features, mask, pos_margin=0.2, neg_margin=1.8, log_scale=512, num_kpt=512):
    pos_mask = mask
    neg_mask = 1 - mask
    dists=torch.sqrt(torch.sum((img_features.unsqueeze(-1)-pc_features.unsqueeze(-2))**2,dim=1))
    pos = dists - 1e5 * neg_mask
    pos_weight = (pos - pos_margin).detach()
    pos_weight = torch.max(torch.zeros_like(pos_weight), pos_weight)

    lse_positive_row = torch.logsumexp(log_scale * (pos - pos_margin) * pos_weight, dim=-1)
    lse_positive_col = torch.logsumexp(log_scale * (pos - pos_margin) * pos_weight, dim=-2)

    neg = dists + 1e5 * pos_mask
    neg_weight = (neg_margin - neg).detach()
    neg_weight = torch.max(torch.zeros_like(neg_weight), neg_weight)

    lse_negative_row = torch.logsumexp(log_scale * (neg_margin - neg) * neg_weight, dim=-1)
    lse_negative_col = torch.logsumexp(log_scale * (neg_margin - neg) * neg_weight, dim=-2)

    loss_col = F.softplus(lse_positive_row + lse_negative_row) / log_scale
    loss_row = F.softplus(lse_positive_col + lse_negative_col) / log_scale
    loss = loss_col + loss_row


    return torch.mean(loss), dists



def det_loss(img_score_inline,img_score_outline,pc_score_inline,pc_score_outline,dists,mask):
    pids=torch.FloatTensor(np.arange(mask.size(-1))).to(mask.device)
    diag_mask=torch.eq(torch.unsqueeze(pids,dim=1),torch.unsqueeze(pids,dim=0)).unsqueeze(0).expand(mask.size()).float()
    furthest_positive,_=torch.max(dists*diag_mask,dim=1)     #(B,N)
    closest_negative,_=torch.min(dists+1e5*mask,dim=1)  #(B,N)
    #loss_inline=torch.mean((furthest_positive-closest_negative)*(img_score_inline.squeeze()+pc_score_inline.squeeze())) +torch.mean(1-img_score_inline)+torch.mean(1-pc_score_inline)
    loss_inline=torch.mean(1-img_score_inline)+torch.mean(1-pc_score_inline)
    loss_outline=torch.mean(img_score_outline)+torch.mean(pc_score_outline)
    return loss_inline+loss_outline

def adapt_loss(img_features, pc_features, mask, margin=0.1, gamma=128, pos_weight=2.0, neg_weight=0.1):
    # Positive and negative masks
    pos_mask = mask
    neg_mask = 1 - mask

    # Compute cosine similarity (dot product)
    dists = torch.sum(img_features.unsqueeze(-1) * pc_features.unsqueeze(-2), dim=1)  # (B, N_img, N_pc)

    # Positive and negative pairs
    pos = dists * pos_mask
    neg = dists * neg_mask

    # Adaptive margin and alpha calculation
    delta_p = 1 - margin
    delta_n = margin
    alpha_p = torch.clamp_min(-pos.detach() + 1 + margin, min=0.0)
    alpha_n = torch.clamp_min(neg.detach() + margin, min=0.0)

    # Avoid numerical issues
    pos = torch.where(pos_mask > 0, pos, torch.tensor(delta_p, device=pos.device))
    neg = torch.where(neg_mask > 0, neg, torch.tensor(delta_n, device=neg.device))

    # Logits with gamma scaling and weights
    logit_p = -alpha_p * (pos - delta_p) * gamma * pos_weight
    logit_n = alpha_n * (neg - delta_n) * gamma * neg_weight

    # Logsumexp for stability
    lse_positive = torch.logsumexp(logit_p, dim=-1)
    lse_negative = torch.logsumexp(logit_n, dim=-1)

    # Combined loss (only row-wise to reduce redundancy)
    loss = F.softplus(lse_positive + lse_negative)

    return torch.mean(loss), dists


def pose_loss(R_pred, R_T, T_pred, T_T):
    R_pred_inv = np.linalg.inv(R_pred)
    RTR=R_pred_inv@R_T
    RTR_tensor = torch.tensor(RTR, dtype=torch.float32)
    RTR_np = RTR_tensor.numpy()  # 将 tensor 转换为 numpy 数组
    rotation = Rotation.from_matrix(RTR_np)  # 从旋转矩阵创建 Rotation 对象
    euler_angles = rotation.as_euler('xyz', degrees=True)
    euler_angles2 = torch.tensor(euler_angles, dtype=torch.float32)
    R_D = torch.sum(torch.abs(euler_angles2))
    T_D = np.linalg.norm(T_pred - T_T)
    pose_loss=(R_D+T_D)*0.5
    return pose_loss



def pose_loss_differentiable(R_pred, R_T, T_pred, T_T, weight=0.5):
    """
    可微的位姿损失。假设 R_pred 和 R_T 均为 (B, 3, 3) 或 (3, 3) 的旋转矩阵，
    T_pred 和 T_T 为对应的平移向量。
    旋转部分采用 geodesic 距离，平移部分采用 L2 范数，两者加权平均。
    """
    # 如果输入为单个样本，则添加 batch 维度
    if R_pred.dim() == 2:
        R_pred = R_pred.unsqueeze(0)
        R_T = R_T.unsqueeze(0)
        T_pred = T_pred.unsqueeze(0)
        T_T = T_T.unsqueeze(0)

    # 计算旋转误差：R_diff = R_predᵀ * R_T
    R_diff = torch.matmul(R_pred.transpose(-1, -2), R_T)
    # 计算 trace
    trace_R = R_diff.diagonal(offset=0, dim1=-2, dim2=-1).sum(-1)
    # 计算余弦值，并 clamp 保证数值稳定
    cos_theta = (trace_R - 1) / 2
    cos_theta = cos_theta.clamp(-1 + 1e-7, 1 - 1e-7)
    theta = torch.acos(cos_theta)  # 得到旋转角（单位：弧度）

    # 平移误差：采用 L2 范数
    T_error = torch.norm(T_pred - T_T, dim=-1)

    # 最终损失：旋转误差和平移误差加权平均
    loss = weight * theta.mean() + (1 - weight) * T_error.mean()
    return loss


if __name__ == '__main__':
   # a = torch.rand(12,64,512)
   # b = torch.rand(12,64,512)
   # c=torch.rand(12,512,512)
   #
   #
   # print(desc_loss_2(a,b,c))
   #
   # print(adapt_loss(a, b, c))


    R_pred = np.array([[1, 0, 0], [0, 1, 0], [0, 0, 1]])
    R_T = np.array([[1, 0, 0], [0, 1, 0.2], [0, 0, 1]])
    T_pred = np.array([0, 0, 0])
    T_T = np.array([0, 0, 0])
    pose_loss=pose_loss_differentiable(R_pred, R_T, T_pred, T_T)
    print(pose_loss)