import os

os.environ["CUDA_VISIBLE_DEVICES"] = "0,1"
import torch
import time
import argparse
import torch.nn as nn
from models.IPTD_network import IPTMMatchNet
from models.IPTD_dataset import kitti_pc_img_dataset
import utils.loss as loss
from utils.loss import adapt_loss, det_loss, pose_loss, desc_loss_2
from torch.optim.lr_scheduler import ReduceLROnPlateau
import numpy as np
import datetime
import logging
import torch.nn.utils as utils2
import math
import utils.options as options
import cv2
from scipy.spatial.transform import Rotation
from utils.DifferentiableRANSAC import DifferentiableRANSAC, RANSACPoseLoss

def get_P_diff(P_pred_np, P_gt_np):
    P_diff = np.dot(np.linalg.inv(P_pred_np), P_gt_np)
    t_diff = np.linalg.norm(P_diff[0:3, 3])
    r_diff = P_diff[0:3, 0:3]
    R_diff = Rotation.from_matrix(r_diff)
    angles_diff = np.sum(np.abs(R_diff.as_euler('xzy', degrees=True)))
    return t_diff * args.Unit_normalization, angles_diff * args.Unit_normalization

def test_acc_trans(model, testdataloader, args):
    model.eval()
    t_diff_set = []
    angles_diff_set = []
    batch_losses = []
    batch_loss_desc = []
    batch_loss_adapt = []
    batch_loss_det = []
    batch_loss_damage = []
    batch_loss_pose = []
    loss_d = nn.MSELoss()
    total_tp = 0
    total_fn = 0

    with torch.no_grad():
        for step, data in enumerate(testdataloader):
            img = data['img'].cuda()
            pc_all = data['pc'].cuda()
            intensity = data['intensity'].cuda()
            sn = data['sn'].cuda()
            K_all = data['K'].cuda()
            K_4_all = data['K_4'].cuda()
            P_all = data['P'].cuda()
            times = data['time'].cuda()
            damages = data['damage'].cuda()
            img_mask = data['img_mask'].cuda()
            pc_kpt_idx = data['pc_kpt_idx'].cuda()
            pc_outline_idx = data['pc_outline_idx'].cuda()
            img_kpt_idx = data['img_kpt_idx'].cuda()
            img_outline_idx = data['img_outline_index'].cuda()
            seq = data['seq']
            PT = data['PT'].cuda()

            B = img_mask.size(0)
            img_x = torch.linspace(0, img_mask.size(-1) - 1, img_mask.size(-1)) \
                .view(1, -1).expand(img_mask.size(-2), img_mask.size(-1)) \
                .unsqueeze(0).expand(B, img_mask.size(-2), img_mask.size(-1)) \
                .unsqueeze(1).cuda()
            img_y = torch.linspace(0, img_mask.size(-2) - 1, img_mask.size(-2)) \
                .view(-1, 1).expand(img_mask.size(-2), img_mask.size(-1)) \
                .unsqueeze(0).expand(B, img_mask.size(-2), img_mask.size(-1)) \
                .unsqueeze(1).cuda()
            img_xy = torch.cat((img_x, img_y), dim=1)

            img_features, pc_features, img_score, pc_score, LSTM_damage = model(pc_all, intensity, sn, img, times)
            pc_features_inline = torch.gather(pc_features, index=pc_kpt_idx.unsqueeze(1).expand(B, pc_features.size(1),
                                                                                                args.num_kpt), dim=-1)

            img_features_flatten = img_features.contiguous().view(B, img_features.size(1), -1)
            img_score_flatten = img_score.contiguous().view(B, img_score.size(1), -1)
            img_xy_flatten = img_xy.contiguous().view(B, 2, -1)

            img_features_flatten_inline = torch.gather(img_features_flatten, index=img_kpt_idx.unsqueeze(1).expand(B,
                                                                                                                   img_features_flatten.size(
                                                                                                                       1),
                                                                                                                   args.num_kpt),
                                                       dim=-1)
            img_xy_flatten_inline = torch.gather(img_xy_flatten,
                                                 index=img_kpt_idx.unsqueeze(1).expand(B, 2, args.num_kpt), dim=-1)
            img_score_flatten_inline = torch.gather(img_score_flatten, index=img_kpt_idx.unsqueeze(1), dim=-1)

            img_features_flatten_outline = torch.gather(img_features_flatten,
                                                        index=img_outline_idx.unsqueeze(1).expand(B,
                                                                                                  img_features_flatten.size(
                                                                                                      1), args.num_kpt),
                                                        dim=-1)
            img_score_flatten_outline = torch.gather(img_score_flatten, index=img_outline_idx.unsqueeze(1), dim=-1)
            pc_score_inline = torch.gather(pc_score, index=pc_kpt_idx.unsqueeze(1), dim=-1)

            pc_xyz_inline = torch.gather(pc_all, index=pc_kpt_idx.unsqueeze(1).expand(B, 3, args.num_kpt), dim=-1)
            pc_xyz_projection = torch.bmm(K_all, (torch.bmm(P_all[:, 0:3, 0:3], pc_xyz_inline) + P_all[:, 0:3, 3:]))
            pc_xy_projection = pc_xyz_projection[:, 0:2, :] / pc_xyz_projection[:, 2:, :]

            diff = img_xy_flatten_inline.unsqueeze(-1) - pc_xy_projection.unsqueeze(-2)
            distance = torch.sqrt(torch.sum(diff ** 2, dim=1))
            correspondence_mask = (distance <= args.dist_thres).float()

            loss_desc, dists = desc_loss_2(img_features_flatten_inline, pc_features_inline, correspondence_mask,
                                           pos_margin=args.pos_margin, neg_margin=args.neg_margin, num_kpt=args.num_kpt)
            loss_adapt, dists2 = adapt_loss(img_features_flatten_inline, pc_features_inline, correspondence_mask,
                                            margin=args.margin, gamma=args.gamma)
            loss_det = det_loss(img_score_flatten_inline.squeeze(), img_score_flatten_outline.squeeze(),
                                pc_score_inline.squeeze(), pc_score_inline.squeeze(), dists, correspondence_mask)
            loss_damage = loss_d(LSTM_damage.squeeze(1), damages)

            ransac = DifferentiableRANSAC(num_iter=5, num_hypotheses=8).cuda()
            pose_loss_fn = RANSACPoseLoss().cuda()
            confidence = torch.einsum('bi,bj->bij', img_score_flatten_inline.squeeze(1),
                                      pc_score_inline.squeeze(1)).mean(dim=1)
            pred_poses, inlier_masks = ransac(torch.transpose(img_xy_flatten_inline, 1, 2),
                                              torch.transpose(pc_xyz_inline, 1, 2),
                                              K_all, confidence=confidence)
            pose_loss = pose_loss_fn(pred_poses, P_all, confidence)

            if epoch < 10:
                loss_weight = {'desc': 1, 'adopt': 0.5,'det': 0.9, 'damage': 0.1, 'pose': 1}
            elif epoch < 40:
                loss_weight = {'desc': 1, 'adopt':0.5, 'det': 0.5, 'damage': 0.5, 'pose': 1}
            else:
                loss_weight = {'desc': 1, 'adopt':0.5, 'det': 0.4, 'damage': 0.6, 'pose': 1}

            loss = 0*loss_weight['desc'] * loss_desc + loss_weight['adopt'] * loss_adapt + loss_weight['det'] * loss_det + loss_weight['damage'] * loss_damage + loss_weight['pose'] * pose_loss
            pred_mask_img = (img_score_flatten_inline.squeeze() > 0.9).float()
            pred_mask_pc = (pc_score_inline.squeeze() > 0.9).float()
            pred_mask = pred_mask_img.unsqueeze(-1) * pred_mask_pc.unsqueeze(-2)
            tp = torch.sum(pred_mask * correspondence_mask).item()
            fn = torch.sum((1 - pred_mask) * correspondence_mask).item()
            total_tp += tp
            total_fn += fn

            batch_losses.append(loss.item())
            batch_loss_desc.append(loss_desc.item())
            batch_loss_adapt.append(loss_adapt.item())
            batch_loss_det.append(loss_det.item())
            batch_loss_damage.append(loss_damage.item())
            batch_loss_pose.append(pose_loss.item())

            loss_d = nn.HuberLoss()
            batch_mae = loss_d(LSTM_damage.squeeze(1), damages)

            bs = img_score.shape[0]

            for i in range(bs):
                imgi = img[i]
                img_scorei = img_score[i]
                pc_scorei = pc_score[i]
                img_feature = img_features[i]
                pc_feature = pc_features[i]
                pc = pc_all[i]
                P = P_all[i].data.cpu().numpy()
                K = K_all[i].data.cpu().numpy()
                K_4 = K_4_all[i].data.cpu().numpy()
                pc_featurei = pc_features[i]
                img_x = np.linspace(0, np.shape(img_feature)[-1] - 1, np.shape(img_feature)[-1]).reshape(1, -1).repeat(
                    np.shape(img_feature)[-2], 0).reshape(1, np.shape(img_scorei)[-2], np.shape(img_scorei)[-1])
                img_y = np.linspace(0, np.shape(img_feature)[-2] - 1, np.shape(img_feature)[-2]).reshape(-1, 1).repeat(
                    np.shape(img_feature)[-1], 1).reshape(1, np.shape(img_scorei)[-2], np.shape(img_scorei)[-1])

                img_xy = np.concatenate((img_x, img_y), axis=0)
                img_xy = torch.tensor(img_xy).cuda()

                img_xy_flatten = img_xy.reshape(2, -1)
                img_feature_flatten = img_feature.reshape(np.shape(img_feature)[0], -1)
                img_score_flatten = img_scorei.squeeze().reshape(-1)
                img_index = (img_score_flatten > args.img_thres)
                img_xy_flatten_sel = img_xy_flatten[:, img_index]
                img_feature_flatten_sel = img_feature_flatten[:, img_index]

                img_score_flatten_sel = img_score_flatten[img_index]
                if img_xy_flatten_sel.shape[1] > 5120:
                    img_xy_flatten_sel = img_xy_flatten_sel[:, :5120]
                    img_feature_flatten_sel = img_feature_flatten_sel[:, :5120]

                pc_index = (pc_scorei.squeeze() > args.pc_thres)

                pc_sel = pc[:, pc_index]
                pc_feature_sel = pc_feature[:, pc_index]

                pc_score_sel = pc_scorei.squeeze()[pc_index]
                if pc_sel.shape[1] > 5120:
                    pc_sel = pc_sel[:, :5120]
                    pc_feature_sel = pc_feature_sel[:, :5120]

                dist = 1 - torch.sum(img_feature_flatten_sel.unsqueeze(2) * pc_feature_sel.unsqueeze(1), dim=0)
                sel_index = torch.argsort(dist, dim=1)[:, 0]

                pc_sel = pc_sel[:, sel_index].detach().cpu().numpy()
                img_xy_pc = img_xy_flatten_sel.detach().cpu().numpy()

                is_success, R, t, inliers = cv2.solvePnPRansac(pc_sel.T, img_xy_pc.T, K, useExtrinsicGuess=False,
                                                               iterationsCount=500,
                                                               reprojectionError=0.125,
                                                               flags=cv2.SOLVEPNP_EPNP,
                                                               distCoeffs=None)

                R, _ = cv2.Rodrigues(R)
                T_pred = np.eye(4)
                T_pred[0:3, 0:3] = R
                T_pred[0:3, 3:] = t
                t_diff, angles_diff = get_P_diff(T_pred, P)
                if t_diff < 100 and angles_diff < 100:
                    t_diff_set.append(t_diff)
                    angles_diff_set.append(angles_diff)

    t_diff_set = np.array(t_diff_set)
    angles_diff_set = np.array(angles_diff_set)
    recall = total_tp / (total_tp + total_fn + 1e-6)
    index = (angles_diff_set < 5) & (t_diff_set < 10)
    return np.nanmean(t_diff_set), np.nanmean(angles_diff_set), (torch.mean(batch_mae)).cpu().numpy(), recall

if __name__ == '__main__':

    parser = argparse.ArgumentParser(description='Point Cloud Registration')
    parser.add_argument('--epoch', type=int, default=100, metavar='epoch',
                        help='number of epoch to train')
    parser.add_argument('--train_batch_size', type=int, default=21, metavar='train_batch_size',
                        help='Size of train batch')
    parser.add_argument('--val_batch_size', type=int, default=7, metavar='val_batch_size',
                        help='Size of val batch')
    parser.add_argument('--data_path', type=str, default='Training_data_sample', metavar='data_path',
                        help='train and test data path')
    parser.add_argument('--num_workers', type=int, default=8, metavar='num_workers',
                        help='num of CPUs')
    parser.add_argument('--input_pt_num', type=int, default=40960, metavar='num_workers',
                        help='num of CPUs')
    parser.add_argument('--val_freq', type=int, default=105, metavar='val_freq',
                        help='')
    parser.add_argument('--lr', type=float, default=0.001, metavar='lr',
                        help='')
    parser.add_argument('--min_lr', type=float, default=0.00001, metavar='lr',
                        help='minimum learning rate')

    parser.add_argument('--P_tx_amplitude', type=float, default=50, metavar='P_tx_amplitude',
                        help='')
    parser.add_argument('--P_ty_amplitude', type=float, default=50, metavar='P_ty_amplitude',
                        help='')
    parser.add_argument('--P_tz_amplitude', type=float, default=50, metavar='P_tz_amplitude',
                        help='')
    parser.add_argument('--P_Rx_amplitude', type=float, default=2 * math.pi * 0, metavar='P_Rx_amplitude',
                        help='')
    parser.add_argument('--P_Ry_amplitude', type=float, default=math.pi * 1, metavar='P_Ry_amplitude',
                        help='')
    parser.add_argument('--P_Rz_amplitude', type=float, default=2 * math.pi * 0, metavar='P_Rz_amplitude',
                        help='')

    parser.add_argument('--save_path', type=str, default='./outs', metavar='save_path',
                        help='path to save log and model')

    parser.add_argument('--exp_name', type=str, default='test', metavar='save_path',
                        help='path to save log and model')

    parser.add_argument('--num_kpt', type=int, default=512, metavar='num_kpt',
                        help='')
    parser.add_argument('--dist_thres', type=float, default=500, metavar='num_kpt',
                        help='')

    parser.add_argument('--img_thres', type=float, default=0, metavar='img_thres',
                        help='')
    parser.add_argument('--pc_thres', type=float, default=0, metavar='pc_thres',
                        help='')

    parser.add_argument('--pos_margin', type=float, default=0.5, metavar='pos_margin',
                        help='')
    parser.add_argument('--neg_margin', type=float, default=1.4, metavar='neg_margin',
                        help='')
    parser.add_argument('--margin', type=float, default=0.6, metavar='margin',
                        help='')
    parser.add_argument('--gamma', type=float, default=64, metavar='gamma',
                        help='')
    parser.add_argument('--load_ckpt', type=str, default='none', metavar='save_path',
                        help='path to save log and model')
    parser.add_argument('--Unit_normalization', type=float, default=0.01, metavar='Unit_normalization',
                        help='')

    parser.add_argument('--mode', type=str, default='none', metavar='save_path',
                        help='path to save log and model')

    args = parser.parse_args()

    if not os.path.exists(args.save_path):
        os.makedirs(args.save_path)
    current_time = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    logdir = os.path.join(args.save_path, current_time)

    checkpoints_dir = os.path.join(logdir, 'checkpoints')
    os.makedirs(checkpoints_dir, exist_ok=True)

    try:
        os.makedirs(logdir)
    except:
        print('mkdir failue')

    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    file_handler = logging.FileHandler('%s/log.txt' % (logdir))
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    train_dataset = kitti_pc_img_dataset(args.data_path, 'train', args.input_pt_num,
                                         P_tx_amplitude=args.P_tx_amplitude,
                                         P_ty_amplitude=args.P_ty_amplitude,
                                         P_tz_amplitude=args.P_tz_amplitude,
                                         P_Rx_amplitude=args.P_Rx_amplitude,
                                         P_Ry_amplitude=args.P_Ry_amplitude,
                                         P_Rz_amplitude=args.P_Rz_amplitude, num_kpt=args.num_kpt, is_front=False)
    test_dataset = kitti_pc_img_dataset(args.data_path, 'val', args.input_pt_num,
                                        P_tx_amplitude=args.P_tx_amplitude,
                                        P_ty_amplitude=args.P_ty_amplitude,
                                        P_tz_amplitude=args.P_tz_amplitude,
                                        P_Rx_amplitude=args.P_Rx_amplitude,
                                        P_Ry_amplitude=args.P_Ry_amplitude,
                                        P_Rz_amplitude=args.P_Rz_amplitude, num_kpt=args.num_kpt, is_front=False)

    trainloader = torch.utils.data.DataLoader(train_dataset, batch_size=args.train_batch_size, shuffle=False,
                                              drop_last=True, num_workers=args.num_workers)
    testloader = torch.utils.data.DataLoader(test_dataset, batch_size=args.val_batch_size, shuffle=False,
                                             drop_last=True, num_workers=args.num_workers)
    opt = options.Options()
    model = IPTMMatchNet(opt)
    model = model.cuda()
    model = torch.nn.DataParallel(model)
    print(f"参数量: {sum(p.numel() for p in model.parameters()) / 1e6:.2f}M")
    current_lr = args.lr
    learnable_params = filter(lambda p: p.requires_grad, model.parameters())
    optimizer = torch.optim.Adam(learnable_params, lr=current_lr)
    scheduler = ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=5, verbose=True)

    logger.info(args)

    global_step = 0

    best_t_diff = 1000
    best_r_diff = 1000
    start_time = time.time()

    for epoch in range(args.epoch):
        epoch_start_time = time.time()
        if train_dataset.mode == 'train':
            train_dataset.update_dataset(epoch)
            trainloader = torch.utils.data.DataLoader(
                train_dataset,
                batch_size=args.train_batch_size,
                shuffle=False,
                drop_last=True,
                num_workers=args.num_workers
            )
        model.train()
        epoch_losses = []
        epoch_loss_desc = []
        epoch_loss_adopt = []
        epoch_loss_det = []
        epoch_loss_damage = []
        epoch_loss_pose = []
        print(f'epoch: {epoch}')
        for step, data in enumerate(trainloader):

            batch_start_time = time.time()
            global_step += 1

            optimizer.zero_grad()
            times = data['time'].cuda()
            damages = data['damage'].cuda()
            img = data['img'].cuda()
            pc = data['pc'].cuda()
            intensity = data['intensity'].cuda()
            sn = data['sn'].cuda()
            K = data['K'].cuda()
            P = data['P'].cuda()
            PT = data['PT'].cuda()
            pc_mask = data['pc_mask'].cuda()
            img_mask = data['img_mask'].cuda()
            B = img_mask.size(0)
            pc_kpt_idx = data['pc_kpt_idx'].cuda()
            pc_outline_idx = data['pc_outline_idx'].cuda()
            img_kpt_idx = data['img_kpt_idx'].cuda()
            img_outline_idx = data['img_outline_index'].cuda()
            seq = data['seq']
            img_x = torch.linspace(0, img_mask.size(-1) - 1, img_mask.size(-1)).view(1, -1).expand(img_mask.size(-2),
                                                                                                   img_mask.size(
                                                                                                       -1)).unsqueeze(
                0).expand(img_mask.size(0), img_mask.size(-2), img_mask.size(-1)).unsqueeze(1).cuda()
            img_y = torch.linspace(0, img_mask.size(-2) - 1, img_mask.size(-2)).view(-1, 1).expand(img_mask.size(-2),
                                                                                                   img_mask.size(
                                                                                                       -1)).unsqueeze(
                0).expand(img_mask.size(0), img_mask.size(-2), img_mask.size(-1)).unsqueeze(1).cuda()
            img_xy = torch.cat((img_x, img_y), dim=1)

            img_features, pc_features, img_score, pc_score, LSTM_damage = model(pc, intensity, sn, img,
                                                                                times)

            pc_features_inline = torch.gather(pc_features, index=pc_kpt_idx.unsqueeze(1).expand(B, pc_features.size(1),
                                                                                                args.num_kpt), dim=-1)
            pc_features_outline = torch.gather(pc_features,
                                               index=pc_outline_idx.unsqueeze(1).expand(B, pc_features.size(1),
                                                                                        args.num_kpt), dim=-1)
            pc_xyz_inline = torch.gather(pc, index=pc_kpt_idx.unsqueeze(1).expand(B, 3, args.num_kpt), dim=-1)
            pc_score_inline = torch.gather(pc_score, index=pc_kpt_idx.unsqueeze(1), dim=-1)
            pc_score_outline = torch.gather(pc_score, index=pc_outline_idx.unsqueeze(1), dim=-1)

            img_features_flatten = img_features.contiguous().view(img_features.size(0), img_features.size(1), -1)
            img_score_flatten = img_score.contiguous().view(img_score.size(0), img_score.size(1), -1)
            img_xy_flatten = img_xy.contiguous().view(img_features.size(0), 2, -1)
            img_features_flatten_inline = torch.gather(img_features_flatten, index=img_kpt_idx.unsqueeze(1).expand(B,
                                                                                                                   img_features_flatten.size(
                                                                                                                       1),
                                                                                                                   args.num_kpt),
                                                       dim=-1)
            img_xy_flatten_inline = torch.gather(img_xy_flatten,
                                                 index=img_kpt_idx.unsqueeze(1).expand(B, 2, args.num_kpt), dim=-1)
            img_score_flatten_inline = torch.gather(img_score_flatten, index=img_kpt_idx.unsqueeze(1), dim=-1)
            img_features_flatten_outline = torch.gather(img_features_flatten,
                                                        index=img_outline_idx.unsqueeze(1).expand(B,
                                                                                                  img_features_flatten.size(
                                                                                                      1), args.num_kpt),
                                                        dim=-1)
            img_score_flatten_outline = torch.gather(img_score_flatten, index=img_outline_idx.unsqueeze(1), dim=-1)

            pc_xyz_projection = torch.bmm(K, (torch.bmm(P[:, 0:3, 0:3], pc_xyz_inline) + P[:, 0:3, 3:]))
            pc_xy_projection = pc_xyz_projection[:, 0:2, :] / pc_xyz_projection[:, 2:, :]

            correspondence_mask = (torch.sqrt(
                torch.sum(torch.square(img_xy_flatten_inline.unsqueeze(-1) - pc_xy_projection.unsqueeze(-2)),
                          dim=1)) <= args.dist_thres).float()

            loss_desc, dists = desc_loss_2(img_features_flatten_inline, pc_features_inline, correspondence_mask, pos_margin=args.pos_margin, neg_margin=args.neg_margin,  num_kpt=args.num_kpt)
            loss_adapt, dists2 = adapt_loss(img_features_flatten_inline, pc_features_inline, correspondence_mask,
                                    margin=args.margin, gamma=args.gamma)
            loss_det = det_loss(img_score_flatten_inline.squeeze(), img_score_flatten_outline.squeeze(),
                                pc_score_inline.squeeze(), pc_score_outline.squeeze(), dists, correspondence_mask)

            loss_d = nn.HuberLoss()
            loss_damage = loss_d(LSTM_damage.squeeze(1), damages)

            ransac = DifferentiableRANSAC(num_iter=100, num_hypotheses=16).cuda()
            pose_loss_fn = RANSACPoseLoss().cuda()
            confidence = torch.einsum('bi,bj->bij',  img_score_flatten_inline.squeeze(1), pc_score_inline.squeeze(1)).mean(dim=1)

            pred_poses, inlier_masks = ransac(
                torch.transpose(img_xy_flatten_inline, 1, 2),
                torch.transpose(pc_xyz_inline, 1, 2),
                K,
                confidence=confidence
            )
            pose_loss = pose_loss_fn(pred_poses, PT, confidence)

            if epoch < 10:
                loss_weight = {'desc': 1, 'adopt': 0.5,'det': 0.9, 'damage': 0.1, 'pose': 1}
            elif epoch < 40:
                loss_weight = {'desc': 1, 'adopt':0.5, 'det': 0.5, 'damage': 0.5, 'pose': 1}
            else:
                loss_weight = {'desc': 1, 'adopt':0.5, 'det': 0.4, 'damage': 0.6, 'pose': 1}

            loss = loss_weight['desc'] * loss_desc + loss_weight['adopt'] * loss_adapt + loss_weight['det'] * loss_det + loss_weight['damage'] * loss_damage + loss_weight['pose'] * pose_loss
            epoch_losses.append(loss.item())
            epoch_loss_desc.append(loss_desc.item())
            epoch_loss_adopt.append(loss_adapt.item())
            epoch_loss_det.append(loss_det.item())
            epoch_loss_damage.append(loss_damage.item())
            epoch_loss_pose.append(pose_loss.item())
            loss.backward()
            optimizer.step()
            batch_end_time = time.time()

            if epoch > 97 and  epoch > 0:
                print(f'seq {torch.tensor(seq,dtype=torch.float32).mean()}, '
                      f'LSTM_damage: {LSTM_damage}, '
                      f'True_damage: {damages}')

            print(f'Batch {step} time: {batch_end_time - batch_start_time:.4f} seconds seq {torch.tensor(seq,dtype=torch.float32).mean()}, '
                  f'Loss: {loss.item():.4f}, Loss desc: {loss_desc.item():.4f},  Loss adopt: {loss_adapt.item():.4f},'
                  f'Loss det: {loss_det.item():.4f}, Loss damage: {loss_damage.item():.4f}, Loss pose: {pose_loss.item():.4f}')

        if global_step % 6 == 0:
            logger.info(f'train-{epoch}-{global_step}, loss: {loss.data.cpu().numpy():.4f}, '
                        f'loss desc: {loss_desc.data.cpu().numpy():.4f}, loss adopt : {loss_adapt.data.cpu().numpy():.4f}, loss det: {loss_det.data.cpu().numpy():.4f}, '
                        f'loss_damage: {loss_damage.data.cpu().numpy():.4f}, loss pose: {pose_loss.data.cpu().numpy():.4f}' )

        if epoch % 5 == 0 and epoch > 0:
            t_diff, r_diff, damage_mae,recall = test_acc_trans(model, testloader, args)
            scheduler.step(r_diff)
            print(f'Validation - Epoch {epoch}, RTE mean: {t_diff:.4f}, RRE mean: {r_diff:.4f}, Damage MAE: {damage_mae:.4f}')
            print(f'Validation - Epoch {epoch}, Recall: {recall:.4f}')
            if t_diff <= best_t_diff:
                torch.save(model.state_dict(), os.path.join(logdir, 'mode_best_t.t7'))
                best_t_diff = t_diff
            if r_diff <= best_r_diff:
                torch.save(model.state_dict(), os.path.join(logdir, 'mode_best_r.t7'))
                best_r_diff = r_diff

            checkpoint = {
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'best_t_diff': best_t_diff,
                'best_r_diff': best_r_diff
            }
            torch.save(checkpoint, os.path.join(checkpoints_dir, f'epoch_{epoch:03d}.pth'))
            scheduler.step(r_diff)

        epoch_end_time = time.time()
        print(f'Epoch {epoch} time: {epoch_end_time - epoch_start_time:.4f} seconds')

    end_time = time.time()
    print(f'Total training time: {end_time - start_time:.4f} seconds')
    torch.save(checkpoint, os.path.join(checkpoints_dir, 'last.pth'))